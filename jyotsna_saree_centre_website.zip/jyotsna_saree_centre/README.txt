JYOTSNA SAREE CENTRE - WEBSITE PREVIEW

1. Open index.html in Chrome, Edge, Firefox or another modern browser.
2. The page is a standalone responsive website; no installation is required.
3. Internet access is needed for Google Fonts and the remote sample catalogue photographs.
4. Product names, prices and catalogue photos are demo placeholders. Replace them with the shop's real inventory before publishing.
5. The location currently displays Kolhapur, Maharashtra, India because no street/shop address was supplied.
6. WhatsApp enquiries open a pre-filled message to 9561192736.

To update products: edit the product cards in index.html.
To update contact details: search for the phone numbers, email and Instagram URL in index.html.
